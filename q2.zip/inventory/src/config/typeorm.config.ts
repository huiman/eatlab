import { TypeOrmModuleOptions } from '@nestjs/typeorm';

export const typeOrmConfig: TypeOrmModuleOptions = {
  type: 'postgres',
  host: 'localhost',
  port: 5432,
  username: 'odoo',
  password: 'odoo',
  database: 'eatlab_inventory',
  entities: [__dirname + '/../../**/*.entity.js'],
  synchronize: true,
  migrations: ['src/migrations/*.js'],
};
