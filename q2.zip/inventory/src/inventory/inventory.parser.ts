import { Injectable } from '@nestjs/common';
import { CsvParser } from 'nest-csv-parser';
import { Product } from './entities/product.entity';

@Injectable()
export class csvService {
  constructor(private readonly csvParser: CsvParser) {}

  async parse() {
    // Create stream from file (or get it from S3)
    // const stream = fs.createReadStream(__dirname + '/some.csv');
    // const products: Product[] = await this.csvParser.parse(stream, Product);
    // return products;
  }
}
