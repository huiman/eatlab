import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Patch,
  Post,
  Query,
  UploadedFile,
  UseInterceptors,
  ValidationPipe,
} from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import { CsvParser } from 'nest-csv-parser';
import { CreateInventoryDto } from './dto/create-inventory.dto';
import { UpdateInventoryDto } from './dto/update-inventory.dto';
import { Product } from './entities/product.entity';
import { InventoryService } from './inventory.service';
import fs = require('fs');
import { GetProductDto } from './dto/get-product.dto';

@Controller('inventory')
export class InventoryController {
  constructor(
    private readonly inventoryService: InventoryService,
    private readonly csvParser: CsvParser,
  ) {}

  @Post('import')
  @UseInterceptors(FileInterceptor('file'))
  async import(@UploadedFile() file: Express.Multer.File) {
    const stream = fs.createReadStream(file.path);
    const products = await this.csvParser.parse(stream, Product);
    return await this.inventoryService.import(products);
  }
  // async import(@UploadedFile() file: multer.File) {
  //   console.log('🚀 ~ file: inventory.controller.ts:35 ~ file:', file);
  //   // const csvPath = getCSVFile();
  //   // console.log(' => ', csvPath);
  //   // const stream = fs.createReadStream(csvPath);
  //   // const entities: Coin[] = await this.csvParser.parse(stream, Coin);
  //   // // You will get JSON
  //   // console.log(entities);

  //   return true;
  //   // return this.inventoryService.create(createInventoryDto);
  // }

  @Post()
  create(@Body() createInventoryDto: CreateInventoryDto) {
    return this.inventoryService.create(createInventoryDto);
  }

  @Get('products')
  findAll(@Query(ValidationPipe) filterDto: GetProductDto) {
    return this.inventoryService.getProducts(filterDto);
  }

  @Get('products/:id')
  findOne(@Param('id') id: number) {
    return this.inventoryService.getProducts({ id });
  }

  @Patch(':id')
  update(
    @Param('id') id: string,
    @Body() updateInventoryDto: UpdateInventoryDto,
  ) {
    return this.inventoryService.update(+id, updateInventoryDto);
  }

  @Delete(':id')
  remove(@Param('id') id: string) {
    return this.inventoryService.remove(+id);
  }
}
