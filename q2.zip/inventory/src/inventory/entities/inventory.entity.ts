import { Column, ManyToOne, PrimaryColumn } from 'typeorm';
import { Product } from './product.entity';
import { InventoryType } from '../inventory.enum';

export class Inventory {
  @PrimaryColumn()
  id: number;

  @Column()
  inventoryType: InventoryType;

  @ManyToOne(() => Product, (product) => product)
  product: Product;

  @Column()
  itemName: string;

  @Column()
  itemDescription: string;

  @Column()
  price: number;

  @Column()
  quantity: number;

  @Column()
  balanceQuan: number;
}
