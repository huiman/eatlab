export enum InventoryType {
  OPEN_BALANCE = 0,
  PURCHASE = 1,
  SALE = 2,
}
