export class CreateInventoryDto {}
