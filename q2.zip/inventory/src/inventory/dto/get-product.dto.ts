import { IsOptional } from 'class-validator';

export class GetProductDto {
  @IsOptional()
  id: number;

  @IsOptional()
  search: string;
}
