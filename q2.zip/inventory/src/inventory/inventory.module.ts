import { Module } from '@nestjs/common';
import { InventoryService } from './inventory.service';
import { InventoryController } from './inventory.controller';
import { CsvModule } from 'nest-csv-parser';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Inventory } from './entities/inventory.entity';
import { MulterModule } from '@nestjs/platform-express';
import { Product } from './entities/product.entity';

@Module({
  imports: [
    TypeOrmModule.forFeature([Inventory]),
    TypeOrmModule.forFeature([Product]),
    CsvModule,
    MulterModule.register({
      dest: './uploads/csv',
    }),
  ],
  controllers: [InventoryController],
  providers: [InventoryService],
})
export class InventoryModule {}
