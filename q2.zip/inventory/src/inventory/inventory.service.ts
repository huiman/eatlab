import { Injectable } from '@nestjs/common';
import { CreateInventoryDto } from './dto/create-inventory.dto';
import { UpdateInventoryDto } from './dto/update-inventory.dto';
import { Product } from './entities/product.entity';
import { Repository } from 'typeorm';
import { InjectRepository } from '@nestjs/typeorm';
import { GetProductDto } from './dto/get-product.dto';

const mockProduct = [
  {
    id: 1,
    name: 'Spaghetti Bolognese',
    description: 'Traditional Italian pasta dish with beef and tomato sauce',
    price: 12.99,
    imageUrl: 'https://example.com/spaghetti-bolognese.jpg',
  },
  {
    id: 2,
    name: 'Chicken Tikka Masala',
    description:
      'A popular Indian curry dish with chicken in a creamy tomato sauce',
    price: 14.99,
    imageUrl: 'https://example.com/chicken-tikka-masala.jpg',
  },
  {
    id: 3,
    name: 'Sushi Platter',
    description: 'A selection of sushi rolls including salmon tuna and avocado',
    price: 19.99,
    imageUrl: 'https://example.com/sushi-platter.jpg',
  },
  {
    id: 4,
    name: 'Pad Thai',
    description:
      'Famous Thai stir-fried rice noodles with shrimp tofu and peanuts',
    price: 15.99,
    imageUrl: 'https://example.com/pad-thai.jpg',
  },
  {
    id: 5,
    name: 'Chicken Caesar Salad',
    description:
      'A classic salad with romaine lettuce grilled chicken croutons and Caesar dressing',
    price: 8.99,
    imageUrl: 'https://example.com/chicken-caesar-salad.jpg',
  },
  {
    id: 6,
    name: 'Beef Burger',
    description:
      'A juicy beef patty served with lettuce tomato and cheese on a bun',
    price: 9.99,
    imageUrl: 'https://example.com/beef-burger.jpg',
  },
  {
    id: 7,
    name: 'Pepperoni Pizza',
    description:
      'A classic pizza topped with tomato sauce mozzarella cheese and pepperoni',
    price: 14.99,
    imageUrl: 'https://example.com/pepperoni-pizza.jpg',
  },
  {
    id: 8,
    name: 'Soba Noodle Soup',
    description:
      'A Japanese soup with buckwheat noodles and vegetables in a savory broth',
    price: 10.99,
    imageUrl: 'https://example.com/soba-noodle-soup.jpg',
  },
  {
    id: 9,
    name: 'Falafel Wrap',
    description: 'A Middle Eastern wrap with falafel lettuce tomato and hummus',
    price: 7.99,
    imageUrl: 'https://example.com/falafel-wrap.jpg',
  },
  {
    id: 10,
    name: 'Chocolate Brownie',
    description: 'A rich chocolate dessert with walnuts and vanilla ice cream',
    price: 6.99,
    imageUrl: 'https://example.com/chocolate-brownie.jpg',
  },
];
@Injectable()
export class InventoryService {
  constructor(
    @InjectRepository(Product) private productRepository: Repository<Product>,
  ) {}
  async import(productcsv) {
    mockProduct.forEach(async (ele) => {
      await this.productRepository
        .createQueryBuilder()
        .insert()
        .into(Product)
        .values(ele)
        .onConflict(`("id") DO NOTHING`)
        .execute();
    });
  }

  create(createInventoryDto: CreateInventoryDto) {
    return 'This action adds a new inventory';
  }

  findAll() {
    return `This action returns all inventory`;
  }

  findOne(id: number) {
    return `This action returns a #${id} inventory`;
  }

  update(id: number, updateInventoryDto: UpdateInventoryDto) {
    return `This action updates a #${id} inventory`;
  }

  remove(id: number) {
    return `This action removes a #${id} inventory`;
  }

  async getProducts(filterDto: Partial<GetProductDto>) {
    const { id } = filterDto;
    const query = this.productRepository.createQueryBuilder();
    if (id !== undefined) {
      query.andWhere('id=:id', { id });
    }
    return await query.getMany();
  }
}
