import { Injectable } from '@nestjs/common';
import { CreateProductDto } from './dto/create-product.dto';
import { UpdateProductDto } from './dto/update-product.dto';
import { Like, Repository } from 'typeorm';
import { Product } from './entities/product.entity';
import { InjectRepository } from '@nestjs/typeorm';
import { getProductDto } from './dto/get-product.dto';

@Injectable()
export class ProductService {
  constructor(
    @InjectRepository(Product) private productRepository: Repository<Product>,
  ) {}

  async create(createProductDto: CreateProductDto) {
    const newProduct = new Product();
    newProduct.name = createProductDto.name;
    newProduct.price = createProductDto.price;
    newProduct.description = createProductDto.description;
    return await newProduct.save();
  }

  async getProducts(filterDto: Partial<getProductDto>) {
    const { id, search } = filterDto;
    const query = this.productRepository.createQueryBuilder();
    if (id !== undefined) {
      query.andWhere('id=:id', { id });
    }
    if (search !== undefined) {
      query.andWhere([
        { title: Like(`%${search}%`) },
        { description: Like(`%${search}%`) },
      ]);
    }
    return await query.getMany();
  }

  findAll() {
    return `This action returns all product`;
  }

  findOne(id: number) {
    return `This action returns a #${id} product`;
  }

  update(id: number, updateProductDto: UpdateProductDto) {
    return `This action updates a #${id} product`;
  }

  remove(id: number) {
    return `This action removes a #${id} product`;
  }
}
