import { IsIn, IsNotEmpty, IsOptional } from 'class-validator';

export class getProductDto {
  @IsOptional()
  id: number;

  @IsOptional()
  search: string;

  @IsOptional()
  price: string;

  @IsOptional()
  imageUrl: string;
}
