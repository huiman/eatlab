import { IsOptional } from 'class-validator';

export class GetOrderDto {
  @IsOptional()
  id: number;

  @IsOptional()
  search: string;
}
