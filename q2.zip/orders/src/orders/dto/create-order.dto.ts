import { Product } from '../entities/product.entity';

export class CreateOrderDto {
  customerName: string;
  product: Product;
  price: number;
  quantity: number;
}
