import { PartialType } from '@nestjs/mapped-types';
import { CreateOrderDto } from './create-order.dto';

export class UpdateOrderDto extends PartialType(CreateOrderDto) {
  customerName: string;
}

export class UpdateOrderLineDto extends PartialType(CreateOrderDto) {
  productName: string;
  price: number;
}
